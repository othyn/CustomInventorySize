data:extend({
	{
		type = "int-setting",
		name = "custom-inventory-size",
		setting_type = "startup",
		minimum_value = 60,
		maximum_value = 480,
		default_value = 120
	}
})